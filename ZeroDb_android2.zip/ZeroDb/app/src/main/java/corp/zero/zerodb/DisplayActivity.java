package corp.zero.zerodb;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


public class DisplayActivity extends AppCompatActivity {

    SQLiteDatabase db;
    ArrayList<String> name=new ArrayList<String>();
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        listView=(ListView)findViewById(R.id.l1);

        db = openOrCreateDatabase("ZeroDB", Context.MODE_PRIVATE, null);
        if (db != null) {
            Toast.makeText(this, "Created", Toast.LENGTH_SHORT).show();
        }
        db.execSQL("CREATE TABLE IF NOT EXISTS tbl_zero(editfname VARCHAR,editmname VARCHAR,editlname VARCHAR);");

        Cursor c = db.rawQuery("SELECT * FROM tbl_zero", null);
        int cnt=c.getCount();
        Toast.makeText(getApplicationContext(),"row count is" +cnt,Toast.LENGTH_LONG).show();
        Log.e("msg","row count is  "+c);


        if (c.getCount() == 0) {

            showMessage("Error", "No records found");
            return;
        }
        StringBuffer buffer = new StringBuffer();
        while (c.moveToNext()) {


            String nm0=c.getString(0).toString();
            String nm1=c.getString(1).toString();
            String nm2=c.getString(2).toString();


            name.add("\t"+nm0+"\t"+nm1+"\t"+nm2+"\t");


        }
        ArrayAdapter<String> ad=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,name);
        listView.setAdapter(ad);

    }


    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}