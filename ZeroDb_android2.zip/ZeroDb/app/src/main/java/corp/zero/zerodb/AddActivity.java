package corp.zero.zerodb;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.app.AlertDialog;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddActivity extends AppCompatActivity {
    EditText editfname, editmname, editlname;
    Button btnAdd, btnDelete, btnModify, btnView, btnViewAll;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        editfname = (EditText) findViewById(R.id.editfname);
        editmname = (EditText) findViewById(R.id.editmname);
        editlname = (EditText) findViewById(R.id.editlname);
        btnAdd = (Button) findViewById(R.id.btnAdd);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        db = openOrCreateDatabase("ZeroDB", Context.MODE_PRIVATE, null);
        if (db != null) {
            Toast.makeText(this, "Created", Toast.LENGTH_SHORT).show();
        }
        db.execSQL("CREATE TABLE IF NOT EXISTS tbl_zero(fname VARCHAR,mname VARCHAR,lname VARCHAR);");

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (editfname.getText().toString().trim().length() == 0 ||
                        editmname.getText().toString().trim().length() == 0 ||
                        editlname.getText().toString().trim().length() == 0) {
                    showMessage("Error", "Please enter all values");
                    return;
                }
                db.execSQL("INSERT INTO tbl_zero VALUES('" + editfname.getText() + "','" + editmname.getText() +
                        "','" + editlname.getText() + "');");
                showMessage("Success", "Record added");
                clearText();
            }

        });


    }

    public void showMessage(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    public void clearText() {
        editfname.setText("");
        editmname.setText("");
        editlname.setText("");
        editfname.requestFocus();
    }
}


