 @extends('layouts.app')

 @section('content')
 <div class="jumbotron text-center">
 <h1>{{$title}}</h1>
 <p><a class="btn btn-primary btn-lg" href="/signin" role="button">Login</a>
    <a class="btn btn-success btn-lg" href="/signup" role="button">Register</a></p>
      
 </div>
 @endsection


