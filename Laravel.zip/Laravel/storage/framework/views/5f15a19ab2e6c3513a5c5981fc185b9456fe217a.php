<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(config('app.name','ZeroApp')); ?></title>


    </head>
    <body>
<h1>Services page</h1>
    </body>
</html>
