<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    //table name change is given here
    protected $table ='posts';
    //primary key
    public $primaryKey= 'id';
    public $timestamp= 'created_at';
}
